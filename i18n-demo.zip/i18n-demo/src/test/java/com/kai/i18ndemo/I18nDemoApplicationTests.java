package com.kai.i18ndemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I18nDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
